criaCartao(
    'Quem eu sou?',
    '',
    'Eu sou Angelo Raphael tenho 16 anos, e levo uma vida boa'
)

criaCartao(
    'Minha familia é?',
    '',
    'Um pouco conturbada'
)

criaCartao(
    'Onde moro?',
    '',
    'eu moro no bairo azaleia, rua Antonio J Silva numero 103, -25.699181, -51.649579'
)

criaCartao(
    'Onde estudo?',
    '',
    'No colegio Everaldo Mario Morski'
)

criaCartao(
    'Minha turma?',
    '',
    'É uma turm meia agitada no geal, porem um otima turma para se conviver'


)

criaCartao(
    'Faculdade?',
    '',
    'Penso em fazer engemharia mecanica'


)

criaCartao(
    'Minha cidade',
    '',
    'O Pinhão apesar de ser uma cidade pequena tem muito a oferecer, como empregos e lugares para sair'


)

criaCartao(
    'Meu sonho',
    '',
    'Meu sonho é construir uma famialia e ter uma carreira bem sucedida no mercado de trabalho'


)